from flask import Flask, jsonify
from flask_cors import CORS
import psycopg2

app = Flask(__name__)
CORS(app)

# Setting PostgreSQL Odoo
DB_HOST = 'localhost'
DB_NAME = 'odoopilot-22102024' 
DB_USER = "admin"  
DB_PASS = "1234"  

# Connect PostgreSQL
def get_db_connection():
    conn = psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
    return conn

@app.route('/api/teams', methods=['GET'])
def get_teams():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT id, name, vote_number, numerical FROM vote_festival_model')
    festivals = cursor.fetchall()
    cursor.close()
    if festivals:
        return jsonify(festivals)
    return jsonify({'message': 'No teams found'}), 404 

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
